﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace compra_ventaVehiculos
{
    public partial class comprarVehiculo : Form
    {
        public comprarVehiculo()
        {
            InitializeComponent();
            cboPago.Enabled = false;
        }
        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MessageBox.Show("Marca: Bugatti\n Año: 2017\n Modelo: Bugatti Vyron\n Color: azul-negro\n Precio: 3.5 millones");
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MessageBox.Show("Marca: Jaguar\n Año: 2018\n Modelo: Jaguar XF\n Color: azul oscuro\n Precio: 2.8 millones");
        }

        private void linkLabel3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MessageBox.Show("Marca: Mclaren\n Año: 2019\n Modelo: Mclaren 720S\n Color: rojo-negro\n Precio: 4 millones");
        }

        private void linkLabel4_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MessageBox.Show("Marca: Pagani\n Año: 2011\n Modelo: Pagani Zonda\n Color: gris\n Precio: 1.2 millones");
        }

        private void linkLabel5_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MessageBox.Show("Marca: Aston Martin\n Año: 2015\n Modelo: Aston Martin Valkyrie\n Color: Celeste\n Precio: 2.5 millones");
        }

        private void linkLabel6_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MessageBox.Show("Marca: Aston Martin\n Año: 2019\n Modelo: Aston Martin Rapide\n Color: rojo\n Precio: $228.781");
        }
        
        private void btnComprar_Click(object sender, EventArgs e)
        {
            txtNombre.Enabled = true;
            txtApellido.Enabled = true;
            txtCedula.Enabled = true;
            txtDir.Enabled = true;
            cboPago.Enabled = true;
            txtTel.Enabled = true;
            txtNombre.Focus();
            if (txtNombre.MaxLength>1&&txtApellido.MaxLength>1&&txtCedula.MaxLength>1&&txtDir.MaxLength>1&&txtTel.MaxLength>1)
            {
                btnGuardar.Enabled = true;
                btnCancelar.Enabled = true;
                btnNuevo.Enabled = true;
            }
            if (radioButton1.Checked==true)
            {
                lstauto.Items.Add("Marca: Bugatti");
                lstauto.Items.Add("Año: 2017");
                lstauto.Items.Add("Modelo: Bugatti Vyron");
                lstauto.Items.Add("Color: azul-negro");
                lstauto.Items.Add("Precio: 3.5 millones");
            }
            if (radioButton2.Checked==true)
            {
                lstauto.Items.Add("Marca: Jaguar");
                lstauto.Items.Add("Año: 2018");
                lstauto.Items.Add("Modelo: Jaguar XF");
                lstauto.Items.Add("Color: azul oscuro");
                lstauto.Items.Add("Precio: 2.8 millones");
            }
            if (radioButton3.Checked==true)
            {
                lstauto.Items.Add("Marca: Mclaren");
                lstauto.Items.Add("Año: 2019");
                lstauto.Items.Add("Modelo: Mclaren 720S");
                lstauto.Items.Add("Color: rojo-negro");
                lstauto.Items.Add("Precio: 4 millones");
            }
            if( radioButton4.Checked==true)
            {
                lstauto.Items.Add("Marca: Pagani");
                lstauto.Items.Add("Año: 2011");
                lstauto.Items.Add("Modelo: Pagani Zonda");
                lstauto.Items.Add("Color: gris");
                lstauto.Items.Add("Precio: 1.2 millones");
            }
            if (radioButton5.Checked == true)
            {
                lstauto.Items.Add("Marca: Aston Martin");
                lstauto.Items.Add("Año: 2015");
                lstauto.Items.Add("Modelo: Aston Martin Valkyrie");
                lstauto.Items.Add("Color: Celeste");
                lstauto.Items.Add("Precio: 2.5 millones");
            }
            if (radioButton6.Checked==true)
            {
                lstauto.Items.Add("Marca: Aston Martin");
                lstauto.Items.Add("Año: 2019");
                lstauto.Items.Add("Modelo: Aston Martin Rapide");
                lstauto.Items.Add("Color: rojo");
                lstauto.Items.Add("Precio: $228.781");
            }
            btnComprar.Enabled = false;
        }
        private void btnGuardar_Click(object sender, EventArgs e)
        {
            string nom, apell, dir, ced, tel, fp, meses;
            nom = txtNombre.Text;
            apell = txtApellido.Text;
            dir = txtDir.Text;
            ced = txtCedula.Text;
            tel = txtTel.Text;
            fp = cboPago.Text;
              if (radioButton7.Checked==true)
                {
                    dataGridView1.Rows.Add(nom, apell, ced, dir, tel, fp, "6 meses");

                }
              else
              {
                  if (radioButton8.Checked == true)
                  {
                      dataGridView1.Rows.Add(nom, apell, ced, dir, tel, fp, "12 meses");
                  }
                  else
                  {
                      if (radioButton9.Checked == true)
                      {
                          dataGridView1.Rows.Add(nom, apell, ced, dir, tel, fp, "24 meses");
                      } 
                  }
              }          
            btnGuardar.Enabled = false;
            btnMonto.Enabled = true;
          
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
            compraVenta c = new compraVenta();
            c.Show();
        }

        private void btnMonto_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked==true)
            {
                txtmonto.Text = ("$ 3.500000");
            }
            if (radioButton2.Checked==true)
            {
                txtmonto.Text = ("$ 2.8000000");
            }
            if (radioButton3.Checked==true)
            {
                txtmonto.Text = ("$ 4.0000000");
            }
            if (radioButton4.Checked==true)
            {
                txtmonto.Text = ("$ 1.2000000");
            }
            if (radioButton5.Checked == true) 
            {
                txtmonto.Text=("$ 2.5000000");
            }
            if (radioButton6.Checked==true)
            {
                txtmonto.Text=("$ 228.781");
            }
            MessageBox.Show("COMPRA REALIZADA CON EXITO...");
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void txtNombre_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            e.Handled = (char.IsNumber(e.KeyChar));
        }

        private void txtApellido_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            e.Handled = (char.IsNumber(e.KeyChar));
        }

        private void txtCedula_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            e.Handled = (char.IsLetter(e.KeyChar));
        }

        private void txtTel_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            e.Handled = (char.IsLetter(e.KeyChar));
        }
        private void limpiar() 
        {
            lstauto.Items.Clear();
            txtApellido.Clear();
            txtmonto.Clear();
            txtTel.Clear();
            txtNombre.Clear();
            txtCedula.Clear();
            txtDir.Clear();
            cboPago.Text = "SELECCIONE";
            radioButton1.Focus();
            dataGridView1.Rows.Clear();
            txtApellido.Enabled = false;
            txtCedula.Enabled = false;
            txtDir.Enabled = false;
            txtmonto.Enabled = false;
            txtNombre.Enabled = false;
            cboPago.Enabled = false;
            btnGuardar.Enabled = false;
            btnMonto.Enabled = false;
            btnNuevo.Enabled = false;
            btnComprar.Enabled = true;
            txtTel.Enabled = false;
            grpCredito.Enabled = false;
        }
        private void btnNuevo_Click(object sender, EventArgs e)
        {
            limpiar();
        }

        private void cboPago_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cboPago.SelectedIndex==0)
            {
                grpCredito.Enabled = true;
              
            }
        }
    }
}
