﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace compra_ventaVehiculos
{
    public partial class venta : Form
    {
        public venta()
        {
            InitializeComponent();
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            string nombre, apellido, cedula, codigo, correo, telefono;
            nombre = txtNombre.Text;
            apellido = txtApellido.Text;
            cedula = txtCedula.Text;
            codigo = txtCodigo.Text;
            correo = txtCorreo.Text;
            telefono = txtTelefono.Text;
            dgvVendedor.Rows.Add(nombre, apellido, cedula, codigo, correo, telefono);
            btnGuardar.Enabled = false;
            groupBox3.Enabled = true;
            groupBox2.Enabled = false;
            button4.Enabled = true;
            txtNombre2.Focus();
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string nombre2, apellido2, telefono2, pais, ciudad, direccion;
            nombre2 = txtNombre2.Text;
            apellido2 = txtApellido2.Text;
            telefono2 = txtTelefono2.Text;
            pais = txtPais.Text;
            ciudad = txtCiudad.Text;
            direccion = txtDireccion2.Text;
            dgvComprador.Rows.Add(nombre2, apellido2, telefono2, pais, ciudad, direccion);
            btnGuardar.Enabled = false;
            MessageBox.Show("Felicidades usted ha vendido un nuevo auto...!!!");
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
            compraVenta c = new compraVenta();
            c.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
            compraVenta c = new compraVenta();
            c.Show();
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void txtCedula_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = (char.IsLetter(e.KeyChar));
        }

        private void txtNombre_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = (char.IsNumber(e.KeyChar));
        }

        private void txtApellido_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = (char.IsNumber(e.KeyChar));
        }

        private void txtCodigo_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = (char.IsLetter(e.KeyChar));
        }

        private void txtTelefono_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = (char.IsLetter(e.KeyChar));
        }

        private void txtNombre2_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = (char.IsNumber(e.KeyChar));
        }

        private void txtApellido2_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = (char.IsNumber(e.KeyChar));
        }

        private void txtTelefono2_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = (char.IsLetter(e.KeyChar));
        }

        private void txtPais_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = (char.IsNumber(e.KeyChar));
        }

        private void txtCiudad_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = (char.IsNumber(e.KeyChar));
        }

        private void btnVender_Click(object sender, EventArgs e)
        {
            txtNombre.Enabled = true;
            txtApellido.Enabled = true;
            txtCedula.Enabled = true;
            txtCodigo.Enabled = true;
            txtTelefono.Enabled = true;
            txtNombre.Focus();
            if (txtNombre.MaxLength > 1 && txtApellido.MaxLength > 1 && txtCedula.MaxLength > 1 && txtCodigo.MaxLength > 1 && txtTelefono.MaxLength > 1 && txtCorreo.MaxLength > 1)
            {
                btnGuardar.Enabled = true;
                btnCancelar.Enabled = true;
            }
            if (radioButton1.Checked == true)
            {
                lstAA.Items.Add("Marca: Bugatti");
                lstAA.Items.Add("Año: 2017");
                lstAA.Items.Add("Modelo: Bugatti Vyron");
                lstAA.Items.Add("Color: azul-negro");
                lstAA.Items.Add("Precio: 3.5 millones");
            }
            if (radioButton2.Checked == true)
            {
                lstAA.Items.Add("Marca: Jaguar");
                lstAA.Items.Add("Año: 2018");
                lstAA.Items.Add("Modelo: Jaguar XF");
                lstAA.Items.Add("Color: azul oscuro");
                lstAA.Items.Add("Precio: 2.8 millones");
            }
            if (radioButton3.Checked == true)
            {
                lstAA.Items.Add("Marca: Mclaren");
                lstAA.Items.Add("Año: 2019");
                lstAA.Items.Add("Modelo: Mclaren 720S");
                lstAA.Items.Add("Color: rojo-negro");
                lstAA.Items.Add("Precio: 4 millones");
            }
            if (radioButton4.Checked == true)
            {
                lstAA.Items.Add("Marca: Pagani");
                lstAA.Items.Add("Año: 2011");
                lstAA.Items.Add("Modelo: Pagani Zonda");
                lstAA.Items.Add("Color: gris");
                lstAA.Items.Add("Precio: 1.2 millones");
            }
            if (radioButton5.Checked == true)
            {
                lstAA.Items.Add("Marca: Aston Martin");
                lstAA.Items.Add("Año: 2015");
                lstAA.Items.Add("Modelo: Aston Martin Valkyrie");
                lstAA.Items.Add("Color: Celeste");
                lstAA.Items.Add("Precio: 2.5 millones");
            }
            if (radioButton6.Checked == true)
            {
                lstAA.Items.Add("Marca: Aston Martin");
                lstAA.Items.Add("Año: 2019");
                lstAA.Items.Add("Modelo: Aston Martin Rapide");
                lstAA.Items.Add("Color: rojo");
                lstAA.Items.Add("Precio: $228.781");
            }
            btnVender.Enabled = false;
            groupBox1.Enabled = false;
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MessageBox.Show("Marca: Bugatti\n Año: 2017\n Modelo: Bugatti Vyron\n Color: azul-negro\n Precio: 3.5 millones");
        }

        private void linkLabel2_LinkClicked_1(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MessageBox.Show("Marca: Jaguar\n Año: 2018\n Modelo: Jaguar XF\n Color: azul oscuro\n Precio: 2.8 millones");
        }

        private void linkLabel3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MessageBox.Show("Marca: Mclaren\n Año: 2019\n Modelo: Mclaren 720S\n Color: rojo-negro\n Precio: 4 millones");
        }

        private void linkLabel4_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MessageBox.Show("Marca: Pagani\n Año: 2011\n Modelo: Pagani Zonda\n Color: gris\n Precio: 1.2 millones");
        }

        private void linkLabel5_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MessageBox.Show("Marca: Aston Martin\n Año: 2015\n Modelo: Aston Martin Valkyrie\n Color: Celeste\n Precio: 2.5 millones");
        }

        private void linkLabel6_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MessageBox.Show("Marca: Aston Martin\n Año: 2019\n Modelo: Aston Martin Rapide\n Color: rojo\n Precio: $228.781");
        }
        private void limpiar() 
        {
            txtApellido2.Clear();
            txtCodigo.Clear();
            txtCedula.Clear();
            txtCiudad.Clear();
            txtApellido.Clear();
            txtCorreo.Clear();
            txtDireccion2.Clear();
            txtNombre.Clear();
            txtNombre2.Clear();
            txtPais.Clear();
            txtTelefono.Clear();
            txtTelefono2.Clear();
            dgvComprador.Rows.Clear();
            dgvVendedor.Rows.Clear();
            lstAA.Items.Clear();
            radioButton1.Focus();
            
        }
        private void btnNuevo1_Click(object sender, EventArgs e)
        {
            limpiar();
        }        
    }
}
